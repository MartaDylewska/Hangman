# Hangman
Hania &amp; Marta hangman for C_School workshop
![login](https://github.com/MartaDylewska/Hangman/blob/master/src/main/resources/Login.PNG)
![create](https://github.com/MartaDylewska/Hangman/blob/master/src/main/resources/Create.PNG)
![hang](https://github.com/MartaDylewska/Hangman/blob/master/src/main/resources/Hangman.PNG)
![onewon](https://github.com/MartaDylewska/Hangman/blob/master/src/main/resources/OneWon.PNG)
![onelost](https://github.com/MartaDylewska/Hangman/blob/master/src/main/resources/OneLost.PNG)
![result](https://github.com/MartaDylewska/Hangman/blob/master/src/main/resources/Result_lost.PNG)
![result](https://github.com/MartaDylewska/Hangman/blob/master/src/main/resources/Result_won.PNG)
