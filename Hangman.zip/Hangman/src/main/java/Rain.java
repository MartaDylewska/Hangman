class Rain {

    private int startX, startY;
    private int endX, endY;

    int getStartX() {
        return startX;
    }

    void setStartX(int startX) {
        this.startX = startX;
    }

    int getStartY() {
        return startY;
    }

    void setStartY(int startY) {
        this.startY = startY;
    }

    int getEndX() {
        return endX;
    }

    void setEndX(int endX) {
        this.endX = endX;
    }

    int getEndY() {
        return endY;
    }

    void setEndY(int endY) {
        this.endY = endY;
    }
}
